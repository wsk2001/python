# kMeansSupportResistance
example of how to use kMeans to detemine support / resistance levels on close prices
